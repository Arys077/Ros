package com.example.jans_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
